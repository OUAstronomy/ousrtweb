#!/usr/bin/env python

import matplotlib.pyplot as plt
import numpy as np

g = 6.67259e-8          # Grav const CGS
ms = 1.98900e+33        # solar mass CGS
standard =ms*1.5*10**10
myg = standard * 3


def rv(my,rad):
    return (2.*g*my/rad)**0.5
def kpc_2_cm(dist):
    return 3.086*10**21*dist


ideal = np.array([[1,2,3,4,5,6,7,8,9],[360,254,207,180,161,147,136,127,120]])
actual = np.array([[0,1.476,2.907,4.250,5.464,6.511,7.361,7.987,8.371,8.5],[30,98.2,195.24,235,241.42,238.52,240.62,246.42,236.67,230.]])
newest = [rv(myg,kpc_2_cm(x))/100000. for x in ideal[0]] #
plt.figure(figsize=[16,10])
plt.plot(ideal[0],ideal[1],color='red',label='Theoretical (1.5E10)')
plt.plot(actual[0],actual[1],color='green',label='Measured')
#plt.plot(ideal[0],newest,color='blue',label='Estimated (3 * Theory)')
plt.xlabel('Tangential Distance')
plt.ylabel('Rotational Velocity')
plt.title('Position Velocity Curve for Milky Way')
plt.legend()
plt.draw()
plt.savefig('combplots.pdf')
plt.show()



