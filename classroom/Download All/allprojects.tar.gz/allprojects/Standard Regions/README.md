Observing Various Standard Regions of Very Well Characterized targets
------------------------------------------------------------------------
DESC: Calibration regions to use to test how sensitive and accurate the telescope and noise diode are.
