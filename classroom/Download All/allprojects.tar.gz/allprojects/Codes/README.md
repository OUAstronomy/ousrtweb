      ___  __  ____  ____  ____
     / __)/  \(    \(  __)/ ___)
    ( (__(  O )) D ( ) _) \___ \
     \___)\__/(____/(____)(____/
----------------------------------------
DESC: Houses the codes and scripts useful for reduction and observation
