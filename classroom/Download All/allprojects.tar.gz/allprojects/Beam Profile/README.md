Characterizing Beam Profile
---------------------------------------------------------------------
DESC: Find and describe the profile of the primary beam for the telescope
