       __     __)
      (, /|  /|               ,
        / | / |  _  __  __     __   _
     ) /  |/  |_(_(_/_)_/_)__(_/ (_(_/_
    (_/   '      .-/ .-/          .-/
                (_/ (_/          (_/
--------------------------------------------
DESC: Map the HI emission along the plane of the galaxy and discover spiral structure
