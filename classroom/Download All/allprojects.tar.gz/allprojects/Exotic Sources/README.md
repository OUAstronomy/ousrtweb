Observing Exotic Sources
---------------------------------------
DESC: Exotic Sources like Andromeda or Casseopeia 
