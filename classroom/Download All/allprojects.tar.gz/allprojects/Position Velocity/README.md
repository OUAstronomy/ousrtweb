Position Velocity Curves of the Milky Way
----------------------------------------------------------------------------
DESC: Find the rotation curve of the milky way galaxy
