Solar Monitoring
---------------------------------------------

DESC: Monitor variations in the sun to measure periods of activity
