        //   ) )
       ((         ___     //  ___      __
         \\     //   ) ) // //   ) ) //  ) )
           ) ) //   / / // //   / / //
    ((___ / / ((___/ / // ((___( ( //
---------------------------------------------

DESC: Monitor variations in the sun to measure periods of activity
