     __     __    _     _   ___   ___    __   _____  _   ___   _
    / /`   / /\  | |   | | | |_) | |_)  / /\   | |  | | / / \ | |\ |
    \_\_, /_/--\ |_|__ |_| |_|_) |_| \ /_/--\  |_|  |_| \_\_/ |_| \|
------------------------------------------------------------------------
DESC: Calibration regions to use to test how sensitive and accurate the telescope and noise diode are.
